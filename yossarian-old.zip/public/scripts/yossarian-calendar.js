var ctrl = angular.module('yossarianCalendar', []);

ctrl.controller('yossarianCalendarEvents', ['$scope', '$http', '$window', '$routeParams',
	function ($scope, $http, $window, $routeParams) { 

		$scope.calendarCategories = [];
		$http.get('/settings/categories').success( function (categories) { $scope.calendarCategories = categories.categories; });

		if ($routeParams.year && $routeParams.month) {

			$scope.currentMonth = moment($routeParams.year + "-" + $routeParams.month, 'YYYY-MM');
		} else {

			$scope.currentMonth = moment();
		}

		$scope.displayMonth = moment($scope.currentMonth).format('MMMM YYYY');
		$scope.checkMonth = moment().format('MMMM YYYY');

		$scope.nextMonth = moment($scope.currentMonth).add('months', 1).format("YYYY/MM");
		$scope.prevMonth = moment($scope.currentMonth).subtract('months', 1).format("YYYY/MM");

		$('.calendar-view').fullCalendar({
			events: [
				{
					title: 'All Day Event',
					start: '2014-08-01'
				},
				{
					title: 'Long Event',
					start: '2014-08-07',
					end: '2014-08-12'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2014-08-09T16:00:00'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2014-08-16T16:00:00'
				},
				{
					title: 'Meeting',
					start: '2014-08-12T10:30:00',
					end: '2014-08-12T12:30:00'
				},
				{
					title: 'Lunch',
					start: '2014-08-12T12:00:00'
				},
				{
					title: 'Birthday Party',
					start: '2014-08-13T07:00:00'
				},
				{
					title: 'Click for Google',
					url: 'http://google.com/',
					start: '2014-08-28'
				}
			],
			dayClick: function (date, jsEvent, view) {
			},
			eventClick: function () {

			},
			eventRender: function () {

			}
		});
		$('.calendar-view').fullCalendar('gotoDate', $scope.currentMonth);
		$(window).trigger('resize');

	}
]);
